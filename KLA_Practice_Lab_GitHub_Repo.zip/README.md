# KLA Practice Lab

A personal semiconductor software practice website with original workshop
statements, milestone input files and problem-specific validator instructions.
Independent of KLA.

Live site: https://kla-practice-lab.vercel.app/

## Problem sets

The PS numbers match this website's menu. They are not official KLA problem IDs.

| PS | Problem | Workshop year |
| --- | --- | --- |
| 01 | SEM Scan Layout Optimization | 2024 |
| 02 | Wafer Mapping | January 2024 |
| 03 | Wafer Processing Optimization | December 2024 |
| 04 | Wafer Inspection Path Planning | December 2025 |
| 05 | Workflow Framework & Defect Binning | 2022 |

## Upload this repository

1. Extract the ZIP on your computer.
2. Create a private GitHub repository named `kla-practice-lab`.
3. Upload these extracted contents. Keep `README.md`, `vercel.json` and
   the `site` folder directly at the repository root. Do not upload the ZIP
   as a single file, and do not add an extra parent directory.
4. Send the GitHub repository link back to continue connecting the existing
   Vercel project. This download itself does not create or link a repository.

For uploading the full folder, GitHub Desktop is convenient: add this folder
as a local repository, commit the files, then publish a private repository.
Alternatively, from this extracted directory with Git installed:

```sh
git init -b main
git add .
git commit -m "Add KLA Practice Lab website"
git remote add origin https://github.com/YOUR_USERNAME/kla-practice-lab.git
git push -u origin main
```

Create an empty private repository first when using these commands. Replace
YOUR_USERNAME with your GitHub username. Authenticate through Git's normal
sign-in flow if requested.

## Run locally

Requires Python 3. No package installation or build step is needed.

```sh
python -m http.server 8000 --bind 127.0.0.1 --directory site
```

Open http://127.0.0.1:8000. Use `python3` on systems where that is the Python 3
command. Do not open index.html directly: the app uses JavaScript modules and
fetches its dataset manifest over HTTP.

## Vercel deployment

`vercel.json` configures a static site with no build or install command and
`site` as the output directory. The Vercel project is `kla-practice-lab` in
the owner's account. Deployment Protection requires the owner's Vercel login.
The `.vercel` directory is local configuration and is excluded from Git.

A Git connection lets Vercel deploy changes from the linked repository.
Never commit credentials, environment files or authentication tokens.

## Saved work

Notes, text attachments and self-recorded progress use browser local storage.
They do not sync between domains, browsers or devices. Use Export progress on
the old site and Restore progress on the new site to migrate work.

## Files

- `site/index.html`, `site/style.css`: page shell and responsive design.
- `site/app.js`, `site/catalog.js`: workspace behavior and problem catalog.
- `site/visuals.js`: illustrative teaching models.
- `site/data/`: original statements and individual input files.
- `site/packs/`: complete material packs, SEM validator and visualizer ZIPs.
- `site/KLA_Practice_Lab_Walkthrough.pptx`: operating guide.

## Validation limits

The original SEM validator is a Windows executable to run locally. The four
other source statements refer to historical hosted validators, which were
unavailable in the recorded checks. Browser checks inspect basic file format
only. The teaching models do not grade code, certify correctness or prove
optimality. The website does not compile or execute submitted code.

## Original sources

- https://github.com/SIVARANJANI-2K/KLA_WORKSHOP
- https://github.com/Sreenidhi-1/KLA-Hackathon
- https://github.com/livin-joseph/UnHack-2024
- https://github.com/Sutharsan-cp/23PD37_SUTHARSAN_CP
- https://github.com/Partha16/KLA-Hackathon

Original materials retain their authors' ownership and applicable terms.
No additional redistribution license is implied. The repository should remain
private for personal practice.
